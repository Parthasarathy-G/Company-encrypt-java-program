import java.util.*;
public class Main{
    public static void main(String args[]){
        psanner ps = new psanner(System.in);
        int a = ps.nextInt(),a1[] = new int[4],a2[] = new int[4];
        String s = "";
        for(int i = 3;i>=0;i--,a/=10){
        a1[i] = a%10;
        }
        for(int i = 0;i<4;i++){
        a1[i] = (a1[i]+5)%10;
        a2[2] = a1[0];
        a2[0] = a1[2];
        a2[3] = a1[1];
        a2[1] = a1[3];
        }
        for(int i =0;i<4;i++){
            s+=Integer.toString(a2[i]);
        }
        System.out.println(Integer.parseInt(s));
    }
}
